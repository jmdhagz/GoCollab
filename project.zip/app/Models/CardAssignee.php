<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CardAssignee extends Model
{
    protected $table = "card_assignees";
}
