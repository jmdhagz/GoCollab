<?php $__env->startSection('content'); ?>
<div id="home">
	<support :boardlist="<?php echo e($board_list); ?>" :ticketlist="<?php echo e($ticket_list); ?>"></support>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>