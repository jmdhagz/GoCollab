<?php $__env->startSection('content'); ?>
<div id="board">
	<nav class="navbar navbar-light" style="background-color: #384c60 !important;">
		<a class="navbar-brand h1" href="#" style="color: white; margin-bottom: 0px !important;">
			<img src="<?php echo e(asset('images/icon.png')); ?>" width="30" height="30" alt="" class="d-inline-block align-top">
			GoCollab
		</a>
		<span class="navbar-text" style="color: white;">
			Welcome, <?php echo e(Auth::user()->name); ?>!
		</span>
	</nav>
	<board :boardlist="<?php echo e($board_list); ?>"></board>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>