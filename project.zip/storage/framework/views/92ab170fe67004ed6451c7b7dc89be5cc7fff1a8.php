<?php $__env->startSection('content'); ?>
<div id="archive">
	<archivenavbar :id="<?php echo e($id); ?>"></archivenavbar>
	<archive :id="<?php echo e($id); ?>" :boardlists="<?php echo e($board_lists); ?>" :cardlists="<?php echo e($card_lists); ?>" :labellists="<?php echo e($label_lists); ?>" :colorlists="<?php echo e($color_lists); ?>" :checklists="<?php echo e($check_lists); ?>" :checklistitems="<?php echo e($checklist_items); ?>" :cardattachment="<?php echo e($card_attachment); ?>"></archive>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>