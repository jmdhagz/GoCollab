<?php $__env->startSection('content'); ?>
<div id="home">
	<navbar :boardinfo="<?php echo e($board_info); ?>" :id="<?php echo e($id); ?>" :boardmemberlist="<?php echo e($board_member_list); ?>" :permissionlist="<?php echo e($permission_list); ?>" :userlist="<?php echo e($user_list); ?>" :userinfo="<?php echo e($user_info); ?>"></navbar>
	<boardlist :id="<?php echo e($id); ?>" :boardlists="<?php echo e($board_lists); ?>" :cardlists="<?php echo e($card_lists); ?>" :labellists="<?php echo e($label_lists); ?>" :colorlists="<?php echo e($color_lists); ?>" :checklists="<?php echo e($check_lists); ?>" :checklistitems="<?php echo e($checklist_items); ?>" :cardattachment="<?php echo e($card_attachment); ?>"></boardlist>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>